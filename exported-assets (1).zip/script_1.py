
import os

# Ensure directories exist
os.makedirs('ecohealth-app/js', exist_ok=True)

# Create the JavaScript file with all functionality
js_content_part1 = """// EcoHealth AI Companion - Main Application JavaScript
// Professional Health Monitoring System with Expanded AI Symptom Checker

const appState = {
    location: null,
    environmental: { aqi: null, pollen: null, pm25: null, pm10: null, ozone: null, lastUpdate: null },
    health: { heartRate: null, symptoms: null, symptomAnalysis: null, riskScore: 0 }
};

const heartRateMonitor = { samples: [], isRunning: false, stream: null, requiredSamples: 150 };

// Comprehensive Symptom Database (20+ symptoms)
const SYMPTOM_DATABASE = {
    'cough': { category: 'Respiratory', severity: 'moderate', keywords: ['cough', 'coughing'], 
        conditions: ['Common Cold', 'Bronchitis', 'Asthma'], triggers: ['air_quality', 'pollen'],
        tips: ['💊 Try cough suppressants', '🍯 Honey soothes throat', '💧 Stay hydrated', '💨 Use humidifier'] },
    'fever': { category: 'General', severity: 'moderate', keywords: ['fever', 'temperature', 'hot'],
        conditions: ['Viral Infection', 'Flu', 'COVID-19'], triggers: ['infection'],
        tips: ['🌡️ Monitor temperature', '💊 Take Tylenol/Advil', '💧 Drink fluids', '🛌 Rest'] },
    'headache': { category: 'Neurological', severity: 'low-moderate', keywords: ['headache', 'head pain', 'migraine'],
        conditions: ['Tension Headache', 'Migraine', 'Dehydration'], triggers: ['stress', 'dehydration'],
        tips: ['💊 Pain relievers', '💧 Drink water', '😴 Rest in dark room', '❄️ Cold compress'] },
    'chest pain': { category: 'Cardiovascular', severity: 'critical', keywords: ['chest pain', 'heart pain'],
        conditions: ['Heart Attack', 'Angina'], triggers: ['stress'],
        tips: ['🚨🚨 CALL 911 IMMEDIATELY', '💊 Chew aspirin', '🪑 Sit down', '🚗 DO NOT DRIVE'] },
    'shortness of breath': { category: 'Respiratory', severity: 'high', keywords: ['shortness of breath', 'breathless'],
        conditions: ['Asthma', 'COPD', 'Anxiety'], triggers: ['air_quality', 'pollen'],
        tips: ['🧘 Sit upright, breathe slowly', '💊 Use inhaler if asthmatic', '⚠️ Seek medical care if severe'] },
    'sore throat': { category: 'Respiratory', severity: 'low-moderate', keywords: ['sore throat', 'throat pain'],
        conditions: ['Viral Pharyngitis', 'Strep Throat'], triggers: ['infection'],
        tips: ['🍯 Honey with warm water', '🧂 Gargle salt water', '💊 Pain relievers', '🍭 Throat lozenges'] },
    'runny nose': { category: 'Allergic', severity: 'low', keywords: ['runny nose', 'stuffy', 'congestion'],
        conditions: ['Allergies', 'Common Cold'], triggers: ['pollen', 'allergens'],
        tips: ['💊 Antihistamines', '💧 Saline rinse', '🌬️ Decongestants', '💨 Steam inhalation'] },
    'nausea': { category: 'Gastrointestinal', severity: 'moderate', keywords: ['nausea', 'sick', 'queasy'],
        conditions: ['Gastroenteritis', 'Food Poisoning'], triggers: ['food', 'infection'],
        tips: ['🍬 Ginger tea/candies', '💧 Sip fluids slowly', '🍪 BRAT diet', '🌬️ Fresh air'] },
    'dizziness': { category: 'Neurological', severity: 'moderate-high', keywords: ['dizzy', 'lightheaded', 'vertigo'],
        conditions: ['Low Blood Pressure', 'Dehydration'], triggers: ['dehydration'],
        tips: ['🪑 Sit down immediately', '💧 Drink water', '🍬 Eat small snack', '⚠️ Seek care if severe'] },
    'fatigue': { category: 'General', severity: 'low-moderate', keywords: ['fatigue', 'tired', 'exhausted'],
        conditions: ['Anemia', 'Poor Sleep', 'Thyroid Issues'], triggers: ['poor_sleep', 'stress'],
        tips: ['😴 Get 7-9 hours sleep', '🥗 Balanced diet', '💧 Stay hydrated', '🏃 Light exercise'] },
    'body ache': { category: 'General', severity: 'low-moderate', keywords: ['body ache', 'muscle pain', 'sore'],
        conditions: ['Viral Infection', 'Flu', 'Overexertion'], triggers: ['infection', 'exertion'],
        tips: ['💊 Ibuprofen/Tylenol', '🔥 Warm bath', '💆 Gentle massage', '🛌 Rest'] },
    'itchy eyes': { category: 'Allergic', severity: 'low', keywords: ['itchy eyes', 'watery eyes'],
        conditions: ['Allergies', 'Hay Fever'], triggers: ['pollen'],
        tips: ['👁️ Avoid rubbing', '💧 Eye drops', '❄️ Cold compress', '🕶️ Wear sunglasses'] },
    'abdominal pain': { category: 'Gastrointestinal', severity: 'moderate-high', keywords: ['stomach pain', 'belly ache'],
        conditions: ['Gastritis', 'Food Poisoning', 'Appendicitis'], triggers: ['food'],
        tips: ['🌡️ Heat pad on abdomen', '💧 Sip clear fluids', '🍚 Bland diet', '🚨 EMERGENCY if severe'] },
    'joint pain': { category: 'Musculoskeletal', severity: 'moderate', keywords: ['joint pain', 'arthritis', 'stiff'],
        conditions: ['Arthritis', 'Gout', 'Injury'], triggers: ['overuse', 'weather'],
        tips: ['💊 Anti-inflammatory', '❄️ Ice for acute pain', '🔥 Heat for chronic', '🏊 Low-impact exercise'] },
    'back pain': { category: 'Musculoskeletal', severity: 'moderate', keywords: ['back pain', 'backache', 'lower back'],
        conditions: ['Muscle Strain', 'Herniated Disc'], triggers: ['poor_posture', 'injury'],
        tips: ['🔥❄️ Heat/ice therapy', '💊 NSAIDs', '🧘 Gentle stretching', '💺 Improve posture'] },
    'rash': { category: 'Dermatological', severity: 'low-moderate', keywords: ['rash', 'hives', 'itchy skin'],
        conditions: ['Allergic Reaction', 'Eczema'], triggers: ['allergens', 'irritants'],
        tips: ['❄️ Cool compress', '💊 Antihistamine', '🧴 Moisturizer', '🚨 EMERGENCY if breathing difficulty'] },
    'insomnia': { category: 'Sleep', severity: 'low-moderate', keywords: ['insomnia', 'cant sleep', 'sleepless'],
        conditions: ['Stress', 'Anxiety', 'Sleep Disorder'], triggers: ['stress', 'caffeine'],
        tips: ['😴 Consistent schedule', '🌙 Dark, cool room', '📱 No screens before bed', '☕ Limit caffeine'] },
    'anxiety': { category: 'Mental Health', severity: 'moderate', keywords: ['anxiety', 'anxious', 'panic', 'nervous'],
        conditions: ['Generalized Anxiety', 'Panic Disorder'], triggers: ['stress'],
        tips: ['🧘 Deep breathing', '💭 Challenge negative thoughts', '🏃 Exercise', '😴 Adequate sleep'] },
    'loss of appetite': { category: 'General', severity: 'moderate', keywords: ['loss of appetite', 'not hungry'],
        conditions: ['Infection', 'Depression', 'GI Issues'], triggers: ['illness', 'stress'],
        tips: ['🍽️ Small frequent meals', '🥤 Nutritious shakes', '💧 Stay hydrated', '🍲 Favorite comfort foods'] }
};

window.addEventListener('DOMContentLoaded', () => {
    initializeApp();
});

function initializeApp() {
    requestLocation();
    updateTimeDisplay();
    setInterval(updateTimeDisplay, 1000);
    updateEnvironmentalData();
    setInterval(updateEnvironmentalData, 300000);
    const textarea = document.getElementById('symptomsInput');
    if (textarea) textarea.addEventListener('input', updateCharCount);
}

function updateTimeDisplay() {
    const now = new Date();
    const timeStr = now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: true });
    const timeDisplay = document.getElementById('timeDisplay');
    if (timeDisplay) timeDisplay.textContent = timeStr;
}

function requestLocation() {
    const locationDisplay = document.getElementById('locationDisplay');
    if (!navigator.geolocation) {
        locationDisplay.textContent = 'Location not supported';
        appState.location = { lat: 19.0760, lon: 72.8777 };
        return;
    }
    navigator.geolocation.getCurrentPosition(
        (position) => {
            appState.location = { lat: position.coords.latitude, lon: position.coords.longitude };
            locationDisplay.textContent = `${appState.location.lat.toFixed(4)}°N, ${appState.location.lon.toFixed(4)}°E`;
        },
        (error) => {
            appState.location = { lat: 19.0760, lon: 72.8777 };
            locationDisplay.textContent = 'Mumbai, India (Default)';
        }
    );
}

function updateEnvironmentalData() {
    const now = new Date();
    const hour = now.getHours();
    const month = now.getMonth();
    let baseAQI = 70;
    if (hour >= 6 && hour <= 9) baseAQI += 40;
    else if (hour >= 17 && hour <= 20) baseAQI += 35;
    else if (hour >= 22 || hour <= 5) baseAQI -= 20;
    baseAQI += Math.random() * 30 - 15;
    baseAQI = Math.max(20, Math.min(200, Math.round(baseAQI)));
    
    let basePollen = 3;
    if (month >= 2 && month <= 5) basePollen = 7;
    else if (month >= 8 && month <= 10) basePollen = 5;
    basePollen += Math.random() * 2 - 1;
    basePollen = Math.max(1, Math.min(10, basePollen));
    
    appState.environmental = {
        aqi: baseAQI,
        pollen: basePollen,
        pm25: Math.round(baseAQI * 0.6),
        pm10: Math.round(baseAQI * 0.8),
        ozone: Math.round(30 + Math.random() * 40),
        lastUpdate: now
    };
    
    updateEnvironmentalUI();
    updateOverviewStats();
}

function updateEnvironmentalUI() {
    const env = appState.environmental;
    document.getElementById('aqiValue').textContent = env.aqi;
    document.getElementById('pm25').textContent = env.pm25 + ' µg/m³';
    document.getElementById('pm10').textContent = env.pm10 + ' µg/m³';
    document.getElementById('ozone').textContent = env.ozone + ' ppb';
    
    let category, className, recommendations;
    if (env.aqi <= 50) {
        category = '🟢 Good';
        className = 'aqi-good';
        recommendations = ['✓ Air quality is excellent', '✓ Perfect for outdoor activities'];
    } else if (env.aqi <= 100) {
        category = '🟡 Moderate';
        className = 'aqi-moderate';
        recommendations = ['• Air quality is acceptable', '• Sensitive: Limit prolonged outdoor exertion'];
    } else {
        category = '🔴 Unhealthy';
        className = 'aqi-unhealthy';
        recommendations = ['⚠️ Everyone may experience health effects', '⚠️ Avoid outdoor activities', '⚠️ Stay indoors'];
    }
    
    const aqiCategory = document.getElementById('aqiCategory');
    aqiCategory.textContent = category;
    aqiCategory.className = 'aqi-category ' + className;
    
    const aqiRecList = document.getElementById('aqiRecList');
    if (aqiRecList) aqiRecList.innerHTML = recommendations.map(r => `<div class="rec-item">${r}</div>`).join('');
    
    document.getElementById('pollenValue').textContent = env.pollen.toFixed(1);
    document.getElementById('pollenFill').style.width = (env.pollen / 10 * 100) + '%';
    
    let pollenLevel = env.pollen < 3 ? 'Low' : env.pollen < 7 ? 'Moderate' : 'High';
    let pollenClass = env.pollen < 3 ? 'pollen-low' : env.pollen < 7 ? 'pollen-moderate' : 'pollen-high';
    document.getElementById('pollenBadge').textContent = pollenLevel;
    document.getElementById('pollenBadge').className = 'pollen-badge ' + pollenClass;
    
    const treeValue = Math.round(env.pollen * 0.4 + Math.random() * 2);
    const grassValue = Math.round(env.pollen * 0.3 + Math.random() * 2);
    const weedValue = Math.round(env.pollen * 0.3 + Math.random());
    
    document.getElementById('treeValue').textContent = treeValue;
    document.getElementById('treeFill').style.width = (treeValue / 10 * 100) + '%';
    document.getElementById('grassValue').textContent = grassValue;
    document.getElementById('grassFill').style.width = (grassValue / 10 * 100) + '%';
    document.getElementById('weedValue').textContent = weedValue;
    document.getElementById('weedFill').style.width = (weedValue / 10 * 100) + '%';
    
    if (env.pollen > 7) {
        const pollenRec = document.getElementById('pollenRec');
        const pollenRecList = document.getElementById('pollenRecList');
        pollenRec.style.display = 'block';
        pollenRecList.innerHTML = `
            <div class="rec-item">🌾 High pollen detected (${env.pollen.toFixed(1)}/10)</div>
            <div class="rec-item">• Take allergy medication</div>
            <div class="rec-item">• Keep windows closed 5am-10am</div>
        `;
    }
}

function updateOverviewStats() {
    const overviewHR = document.getElementById('overviewHR');
    overviewHR.textContent = appState.health.heartRate ? appState.health.heartRate + ' BPM' : 'Not measured';
    
    const overviewSymptoms = document.getElementById('overviewSymptoms');
    if (appState.health.symptomAnalysis) {
        const count = appState.health.symptomAnalysis.matchedSymptoms.length;
        overviewSymptoms.textContent = `${count} symptom${count !== 1 ? 's' : ''} logged`;
    } else {
        overviewSymptoms.textContent = 'None logged';
    }
    
    calculateHealthRisk();
}

function calculateHealthRisk() {
    let riskScore = 0;
    if (appState.environmental.aqi > 150) riskScore += 30;
    else if (appState.environmental.aqi > 100) riskScore += 20;
    if (appState.environmental.pollen > 7) riskScore += 20;
    if (appState.health.heartRate && (appState.health.heartRate < 50 || appState.health.heartRate > 110)) riskScore += 25;
    if (appState.health.symptomAnalysis) {
        const severity = appState.health.symptomAnalysis.overallSeverity;
        if (severity === 'critical') riskScore += 40;
        else if (severity === 'high') riskScore += 30;
        else if (severity === 'moderate') riskScore += 20;
    }
    appState.health.riskScore = Math.min(riskScore, 100);
    
    const overviewRisk = document.getElementById('overviewRisk');
    let riskLevel = riskScore < 30 ? 'Low' : riskScore < 60 ? 'Moderate' : 'High';
    overviewRisk.textContent = `${riskLevel} (${riskScore}/100)`;
}

function switchTab(tabName) {
    document.querySelectorAll('.tab-content').forEach(tab => tab.classList.remove('active'));
    document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
    document.getElementById(tabName).classList.add('active');
    const activeBtn = document.querySelector(`[data-tab="${tabName}"]`);
    if (activeBtn) activeBtn.classList.add('active');
}
"""

# Write first part
with open('ecohealth-app/js/app.js', 'w', encoding='utf-8') as f:
    f.write(js_content_part1)

print("✅ Part 1 of JavaScript written")
